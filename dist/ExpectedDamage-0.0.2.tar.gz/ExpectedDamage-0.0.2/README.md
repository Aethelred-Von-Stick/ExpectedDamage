# Expected Damage

This package will calculate the expected damage to a risk given depth data and a vulnerability curve.
